package ups.demo.demo.ups;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;
import model.Cliente;
import ups.demo.dao.ClienteDAO;

@Singleton
@Startup
public class Inicio {
	
	@Inject
	private ClienteDAO clienteDAO;
	
	@PostConstruct
	public void init() {		
		System.out.println("Hola Mundo");
		
		Cliente cliente = new Cliente();
		cliente.setCedula("0107951170");
		cliente.setNombre("Adrian Campoverde");
		cliente.setDireccion("San Joaquin");
		
		
		clienteDAO.insert(cliente);
		
		clienteDAO.getAll().forEach(e -> System.out.println(e.getCedula() + "|" + e.getNombre()) );
		
	}

}
