package model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Ticket {
    
    @Id
    private int id;

    @OneToOne
    @JoinColumn(name = "cedula")
    private Cliente cliente;

    @OneToOne
    @JoinColumn(name = "id")
    private Rifa rifa;

}
